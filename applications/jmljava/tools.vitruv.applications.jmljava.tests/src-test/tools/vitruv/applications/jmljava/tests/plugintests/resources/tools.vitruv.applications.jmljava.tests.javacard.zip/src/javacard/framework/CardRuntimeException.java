/**
  * This file is part of the KeY Java Card API Reference Implementation.
  *
  * Author: Wojciech Mostowski, woj@cs.ru.nl
  *   
  * For details and license see README and LICENSE files.
  *    
  * $Id: CardRuntimeException.java,v 1.6 2007/07/09 13:19:04 woj Exp $
  */

package javacard.framework;

import de.uka.ilkd.key.javacard.KeYJCSystem;

public class CardRuntimeException extends java.lang.RuntimeException {

    private static /*@spec_public*/ CardRuntimeException _systemInstance;

    protected /*@spec_public*/ short[] _reason;
    
    public CardRuntimeException()
    {}

    public CardRuntimeException(short reason) {
        _reason = JCSystem.makeTransientShortArray((short) 1,
                JCSystem.CLEAR_ON_RESET);
	KeYJCSystem.setJavaOwner(_reason, this);
        _reason[0] = reason;
        if (_systemInstance == null)
            _systemInstance = this;
    }

    public short getReason() {
        return _reason[0];
    }

    public void setReason(short reason) {
        _reason[0] = reason;
    }

    public static void throwIt(short reason) throws CardRuntimeException {
        _systemInstance.setReason(reason);
        throw _systemInstance;
    }

}
